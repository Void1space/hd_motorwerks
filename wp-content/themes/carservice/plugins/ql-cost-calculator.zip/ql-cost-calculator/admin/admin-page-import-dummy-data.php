<div class="wrap cost-calculator-settings-section">
	<h2><?php _e("Cost Calculator Dummy Data", "cost-calculator"); ?></h2>
</div>
<div class="cost-calculator-dummy-button-container">
	<a class="button button-primary" name="cost_calculator_import_dummy" id="cost_calculator_import_dummy"><?php _e('Import dummy content', 'cost-calculator'); ?></a>
	<span class="spinner"></span>
	<img class="cost-calculator-dummy-content-tick" src="<?php echo WP_PLUGIN_URL; ?>/ql-cost-calculator/admin/images/tick.png">
	<div class="cost-calculator-dummy-content-info"></div>
</div>